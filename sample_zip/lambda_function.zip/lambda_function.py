def lambda_handler(event, context):
    result = "Welcome, "+event['name']
    return {
        'statusCode': 200,
        'body': str(result)
    }
